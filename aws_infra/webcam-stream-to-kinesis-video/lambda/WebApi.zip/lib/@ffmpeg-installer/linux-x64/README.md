Do not use directly, use ffmpeg-installer:

    npm install --save @ffmpeg-installer/ffmpeg
    
